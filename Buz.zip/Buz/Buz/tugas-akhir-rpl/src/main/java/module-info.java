module Buz {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires sqlite.jdbc;

    opens id.ac.ukdw.fti.rpl.Buz to javafx.fxml;
    exports id.ac.ukdw.fti.rpl.Buz;
    exports id.ac.ukdw.fti.rpl.Buz.modal;
}

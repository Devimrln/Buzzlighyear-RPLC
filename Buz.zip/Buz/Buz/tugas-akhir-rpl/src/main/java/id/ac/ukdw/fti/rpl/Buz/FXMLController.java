package id.ac.ukdw.fti.rpl.Buz;

import java.net.URL;
import java.util.ResourceBundle;

import id.ac.ukdw.fti.rpl.Buz.database.Database;
import id.ac.ukdw.fti.rpl.Buz.modal.Verse;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class FXMLController implements Initializable {

    @FXML
    private TableView<Verse> tableVerses;

    @FXML
    private TableColumn<Verse, Integer> verseIdColumn;

    @FXML
    private TableColumn<Verse, String> verseColumn;

    @FXML
    private TableColumn<Verse, String> eventsColumn;

    @FXML
    private TableColumn<Verse, String> verseTextColumn;

    @FXML
    private TableColumn<Verse, String> peopleColumn;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<Verse> verses = Database.instance.getAllVerse();
        verseIdColumn.setCellValueFactory(new PropertyValueFactory<Verse, Integer>("verseId"));
        verseColumn.setCellValueFactory(new PropertyValueFactory<Verse, String>("verse"));
        eventsColumn.setCellValueFactory(new PropertyValueFactory<Verse, String>("eventsDescribed"));
        verseTextColumn.setCellValueFactory(new PropertyValueFactory<Verse, String>("verseText"));
        peopleColumn.setCellValueFactory(new PropertyValueFactory<Verse, String>("people"));
        tableVerses.setItems(verses);
    }
}

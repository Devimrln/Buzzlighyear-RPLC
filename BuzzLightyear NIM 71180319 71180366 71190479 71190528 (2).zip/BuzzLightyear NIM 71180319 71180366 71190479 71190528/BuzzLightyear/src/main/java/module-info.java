module BuzzLightyear {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires sqlite.jdbc;

    opens id.ac.ukdw.fti.rpl.BuzzLightyear to javafx.fxml;
    exports id.ac.ukdw.fti.rpl.BuzzLightyear.database;
    exports id.ac.ukdw.fti.rpl.BuzzLightyear.modal;
    exports id.ac.ukdw.fti.rpl.BuzzLightyear;
 


}
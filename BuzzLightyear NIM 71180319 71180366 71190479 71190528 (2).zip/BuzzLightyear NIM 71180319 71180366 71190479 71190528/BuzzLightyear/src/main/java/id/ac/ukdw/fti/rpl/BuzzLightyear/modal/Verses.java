package id.ac.ukdw.fti.rpl.BuzzLightyear.modal;

public class Verses {
    private int verseId;
    private String verse;
    private String events;
    private String period;
    private String verseText;
    

    public void setVerseId(int verseId) {
       this.verseId = verseId;
    }

    public void setVerse(String verse) {
        this.verse = verse;
    }
    public void setEvents(String events) {
        events = events;
    }
    public void setPeriod(String period) {
        period = period;
    }

    public void setVerseText(String verseText) {
        this.verseText = verseText;
    }

    public int getVerseId() {
        return this.verseId;
    }

    public String getVerse() {
        return this.verse;
    }
    public String getEvents() {
        return this.events;
    }
    public String getPeriod() {
        return this.period;
    }

    public String getVerseText() {
        return this.verseText;
    }
    
}
